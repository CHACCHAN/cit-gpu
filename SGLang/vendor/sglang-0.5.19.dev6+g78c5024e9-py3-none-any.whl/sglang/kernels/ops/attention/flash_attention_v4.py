from __future__ import annotations

import os
from typing import Callable, Optional, Tuple, Union

import torch
import torch.nn.functional as F

from sglang.kernel_api_logging import debug_kernel_api

try:
    if os.environ.get("SGLANG_INKLING_FA4_USE_PIP") == "1":
        # A/B debug escape hatch: route through the pip flash-attn-4 package
        # (dev's stack). rel_bias is vendored-only, so SHEARED must be 0.
        from flash_attn.cute import flash_attn_varlen_func as _flash_attn_varlen_func
    else:
        from sglang.kernels.ops.attention.flash_attn.cute import (
            flash_attn_varlen_func as _flash_attn_varlen_func,
        )
except Exception as _e:  # pragma: no cover
    _flash_attn_varlen_func = None
    _flash_attn_import_error = _e
else:
    _flash_attn_import_error = None


def is_flash_attention_v4_available() -> bool:
    return _flash_attn_varlen_func is not None


def _maybe_contiguous(x: Optional[torch.Tensor]) -> Optional[torch.Tensor]:
    return x.contiguous() if x is not None and x.stride(-1) != 1 else x


def _pad_mla_q_heads(q, qv, v, pack_gqa):
    if qv is None or pack_gqa is False:
        return q, qv, None

    num_heads = qv.shape[-2]
    num_kv_heads = v.shape[-2]
    qhead_per_kvhead = num_heads // num_kv_heads
    if 128 % qhead_per_kvhead == 0 or qhead_per_kvhead % 128 == 0:
        return q, qv, None

    qhead_per_kvhead_padded = 1 << (qhead_per_kvhead - 1).bit_length()

    def pad(x):
        if x is None:
            return None
        prefix = x.shape[:-2]
        x = x.reshape(*prefix, num_kv_heads, qhead_per_kvhead, x.shape[-1])
        x = F.pad(x, (0, 0, 0, qhead_per_kvhead_padded - qhead_per_kvhead))
        return x.reshape(*prefix, num_kv_heads * qhead_per_kvhead_padded, x.shape[-1])

    # Pad each KV group to a valid ratio so MLA stays on the packed kernel.
    return (
        pad(q),
        pad(qv),
        (
            num_kv_heads,
            qhead_per_kvhead,
            qhead_per_kvhead_padded,
        ),
    )


def _unpad_mla_result(result, head_padding):
    if head_padding is None:
        return result

    num_kv_heads, qhead_per_kvhead, qhead_per_kvhead_padded = head_padding
    out, lse = result
    prefix = out.shape[:-2]
    out = out.reshape(*prefix, num_kv_heads, qhead_per_kvhead_padded, out.shape[-1])[
        ..., :qhead_per_kvhead, :
    ]
    out = out.reshape(
        *prefix, num_kv_heads * qhead_per_kvhead, out.shape[-1]
    ).contiguous()
    if lse is not None:
        prefix = lse.shape[:-1]
        lse = lse.reshape(*prefix, num_kv_heads, qhead_per_kvhead_padded)[
            ..., :qhead_per_kvhead
        ]
        lse = lse.reshape(*prefix, num_kv_heads * qhead_per_kvhead).contiguous()
    return out, lse


@debug_kernel_api
def flash_attn_varlen_func(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    cu_seqlens_q: Optional[torch.Tensor] = None,
    cu_seqlens_k: Optional[torch.Tensor] = None,
    qv: Optional[torch.Tensor] = None,
    seqused_q: Optional[torch.Tensor] = None,
    seqused_k: Optional[torch.Tensor] = None,
    max_seqlen_q: Optional[int] = None,
    max_seqlen_k: Optional[int] = None,
    page_table: Optional[torch.Tensor] = None,
    softmax_scale: Optional[float] = None,
    causal: bool = False,
    softcap: Optional[float] = None,
    window_size: Tuple[Optional[int], Optional[int]] = (-1, -1),
    learnable_sink: Optional[torch.Tensor] = None,
    sinks: Optional[torch.Tensor] = None,
    num_splits: int = 1,
    pack_gqa: Optional[bool] = None,
    score_mod: Optional[Callable] = None,
    aux_tensors: Optional[list] = None,
    q_descale: Optional[
        torch.Tensor
    ] = None,  # legacy per-tensor FP8 descale scalar (fp8_e4m3/e5m2 KV)
    k_descale: Optional[torch.Tensor] = None,  # legacy per-tensor FP8 descale scalar
    v_descale: Optional[torch.Tensor] = None,  # legacy per-tensor FP8 descale scalar
    sfq: Optional[
        torch.Tensor
    ] = None,  # MXFP8 UE8M0 per-32-elem block scales (block-scaled QK^T)
    sfk: Optional[
        torch.Tensor
    ] = None,  # MXFP8 UE8M0 per-32-elem block scales (block-scaled QK^T)
    sfv: Optional[
        torch.Tensor
    ] = None,  # MXFP8 UE8M0 per-32-elem block scales (in-kernel V dequant)
    rel_bias: Optional[torch.Tensor] = None,
    rel_bias_prep_cache: Optional[dict] = None,
    return_softmax_lse: bool = False,
    **_: object,
):
    if _flash_attn_varlen_func is None:  # pragma: no cover
        raise ImportError(
            "FlashAttention-4 CUTE is not available. Install flash-attn-4 with "
            "its CUDA/CUTE dependencies, or run from a source tree where the "
            "vendored FA4 package is importable."
        ) from _flash_attn_import_error

    q, k, v, qv = [_maybe_contiguous(t) for t in (q, k, v, qv)]
    if qv is None and q.shape[-1] == 256 and k.shape[-1] == 256 and v.shape[-1] == 256:
        # The vendored hd256 kernel assumes dense Q/K/V strides.
        # TODO: Remove this workaround after the FA4 in current environment includes
        # https://github.com/Dao-AILab/flash-attention/pull/2670 (flash-attn-4 >= 4.0.0b20).
        q, k, v = [t.contiguous() for t in (q, k, v)]
    q, qv, mla_head_padding = _pad_mla_q_heads(q, qv, v, pack_gqa)
    if qv is not None and num_splits < 1:
        # FA4 MLA does not implement split-KV; auto mode must use one split.
        num_splits = 1
    cu_seqlens_q, cu_seqlens_k = [
        _maybe_contiguous(t) for t in (cu_seqlens_q, cu_seqlens_k)
    ]
    seqused_q, seqused_k = [_maybe_contiguous(t) for t in (seqused_q, seqused_k)]
    page_table = _maybe_contiguous(page_table)

    if learnable_sink is None and sinks is not None:
        learnable_sink = sinks

    if window_size == (-1, -1):
        window_size = (None, None)

    # sf* = MXFP8 UE8M0 block scale factors (per-32-element), for the
    # block-scaled QK^T / V-dequant path. *_descale = the legacy per-tensor
    # FP8 descale scalars (kv_cache_dtype fp8_e4m3/fp8_e5m2). Only one group is
    # ever populated for a given call. Non-None kwargs only, so bf16/other calls
    # don't hand these to the kernel.
    sf_kwargs = {}
    if sfq is not None:
        sf_kwargs["sfq"] = sfq
    if sfk is not None:
        sf_kwargs["sfk"] = sfk
    if sfv is not None:
        sf_kwargs["sfv"] = sfv

    descale_kwargs = {}
    if q_descale is not None:
        descale_kwargs["q_descale"] = q_descale
    if k_descale is not None:
        descale_kwargs["k_descale"] = k_descale
    if v_descale is not None:
        descale_kwargs["v_descale"] = v_descale

    rel_bias_kwargs = {}
    if rel_bias is not None:
        rel_bias_kwargs["rel_bias"] = rel_bias
    if rel_bias_prep_cache is not None:
        rel_bias_kwargs["rel_bias_prep_cache"] = rel_bias_prep_cache
    result = _flash_attn_varlen_func(
        q=q,
        k=k,
        v=v,
        qv=qv,
        cu_seqlens_q=cu_seqlens_q,
        cu_seqlens_k=cu_seqlens_k,
        seqused_q=seqused_q,
        seqused_k=seqused_k,
        max_seqlen_q=max_seqlen_q,
        max_seqlen_k=max_seqlen_k,
        page_table=page_table,
        softmax_scale=softmax_scale,
        causal=causal,
        softcap=softcap,
        window_size=window_size,
        learnable_sink=learnable_sink,
        num_splits=num_splits,
        pack_gqa=pack_gqa,
        score_mod=score_mod,
        aux_tensors=aux_tensors,
        return_lse=return_softmax_lse,
        **sf_kwargs,
        **descale_kwargs,
        **rel_bias_kwargs,
    )
    result = _unpad_mla_result(result, mla_head_padding)

    if return_softmax_lse:
        return result
    if isinstance(result, tuple):
        return result[0]
    return result


@debug_kernel_api
def flash_attn_with_kvcache(
    q: torch.Tensor,
    k_cache: torch.Tensor,
    v_cache: torch.Tensor,
    k: Optional[torch.Tensor] = None,
    v: Optional[torch.Tensor] = None,
    qv: Optional[torch.Tensor] = None,
    rotary_cos: Optional[torch.Tensor] = None,
    rotary_sin: Optional[torch.Tensor] = None,
    cache_seqlens: Optional[Union[int, torch.Tensor]] = None,
    cache_batch_idx: Optional[torch.Tensor] = None,
    cache_leftpad: Optional[torch.Tensor] = None,
    page_table: Optional[torch.Tensor] = None,
    cu_seqlens_q: Optional[torch.Tensor] = None,
    cu_seqlens_k_new: Optional[torch.Tensor] = None,
    max_seqlen_q: Optional[int] = None,
    rotary_seqlens: Optional[torch.Tensor] = None,
    q_descale: Optional[torch.Tensor] = None,
    k_descale: Optional[torch.Tensor] = None,
    v_descale: Optional[torch.Tensor] = None,
    softmax_scale: Optional[float] = None,
    causal: bool = False,
    window_size: Tuple[int, int] = (-1, -1),
    attention_chunk: Optional[int] = None,
    softcap: float = 0.0,
    rotary_interleaved: bool = True,
    scheduler_metadata=None,
    num_splits: int = 0,
    pack_gqa: Optional[bool] = None,
    sm_margin: int = 0,
    sinks: Optional[torch.Tensor] = None,
    score_mod: Optional[Callable] = None,
    aux_tensors: Optional[list] = None,
    sfq: Optional[torch.Tensor] = None,
    sfk: Optional[torch.Tensor] = None,
    sfv: Optional[torch.Tensor] = None,
    rel_bias: Optional[torch.Tensor] = None,
    rel_bias_prep_cache: Optional[dict] = None,
    return_softmax_lse: bool = False,
    **_: object,
):
    if k is not None or v is not None:
        raise NotImplementedError("FA4 does not support updating KV cache in-place.")
    if rotary_cos is not None or rotary_sin is not None or rotary_seqlens is not None:
        raise NotImplementedError("FA4 path does not support rotary embedding.")
    if cache_batch_idx is not None or cache_leftpad is not None:
        raise NotImplementedError(
            "FA4 path does not support non-consecutive batch indices or left padding."
        )
    if isinstance(cache_seqlens, int):
        cache_seqlens = torch.full(
            (k_cache.shape[0],), cache_seqlens, dtype=torch.int32, device=k_cache.device
        )

    result = flash_attn_varlen_func(
        q=q,
        k=k_cache,
        v=v_cache,
        qv=qv,
        cu_seqlens_q=cu_seqlens_q,
        seqused_k=cache_seqlens,
        max_seqlen_q=max_seqlen_q,
        page_table=page_table,
        softmax_scale=softmax_scale,
        causal=causal,
        softcap=softcap if softcap != 0.0 else None,
        window_size=window_size,
        num_splits=num_splits,
        pack_gqa=pack_gqa,
        learnable_sink=sinks,
        score_mod=score_mod,
        aux_tensors=aux_tensors,
        q_descale=q_descale,
        k_descale=k_descale,
        v_descale=v_descale,
        sfq=sfq,
        sfk=sfk,
        sfv=sfv,
        rel_bias=rel_bias,
        rel_bias_prep_cache=rel_bias_prep_cache,
        return_softmax_lse=True,
    )

    if return_softmax_lse:
        return result
    if isinstance(result, tuple):
        return result[0]
    return result
